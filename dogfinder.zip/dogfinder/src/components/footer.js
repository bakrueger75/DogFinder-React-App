import React from 'react';
import ReactDOM from 'react-dom';

export default class Footer extends React.Component {
  render() {
    return (
		<div id="footerWidget">
			<div id="footerContent">
				Questions? Contact Brian: <a href="mailto:bakrueger75@gmail">bakrueger75@gmail.com</a>
			</div>

		</div>    
	);
  }
}
